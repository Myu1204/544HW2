package edu.csuf.cpsc544.team4;

import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;

import java.util. Random;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

public class PlayActivity extends AppCompatActivity {
    public static final Random RANDOM = new Random();
    private Button rollDices;
    private ImageView imageView1, imageView2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ActionBar actionBar = getSupportActionBar();
        actionBar.hide();
        setContentView(R.layout.activity_play);

        rollDices.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {


            }
        });

    }
    public static int randomDiceValue() {

        return RANDOM.nextInt(6) +1;
    }
}