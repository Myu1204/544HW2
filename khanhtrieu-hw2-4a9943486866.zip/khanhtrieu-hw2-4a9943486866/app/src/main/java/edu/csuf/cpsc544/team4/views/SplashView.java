package edu.csuf.cpsc544.team4.views;

import android.animation.ValueAnimator;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PointF;
import android.util.AttributeSet;
import android.view.View;
import android.view.animation.LinearInterpolator;

import androidx.annotation.Nullable;

import edu.csuf.cpsc544.team4.R;

public class SplashView extends  View{
     Context context;
     private float initialRadius = 0;
     private float maxRadius = 0;
     private float waveRadiusOffset = 0;
     private PointF center = new PointF(100, 100);
     private Paint wavePaint;
     private Float waveGap;
    private ValueAnimator waveAnimator;
     public SplashView(Context c){
         super(c);
         context = c;
         init(null);
     }
    public SplashView(Context c, AttributeSet attrs){
        super(c,attrs);
        context = c;
        init(attrs);
    }
     public SplashView(Context c, AttributeSet attrs,int defStyleAttr){
         super(c,attrs,0);
         context = c;
         init(attrs);

     }

     @Override
     protected void onSizeChanged(int w, int h, int oldw, int oldh) {
         center.set(w / 2f, h / 2f);
         maxRadius = (float) Math.hypot((double)center.x, (double)center.y);
         initialRadius = w / 16;
     }
     @Override
     protected void onDraw(Canvas canvas) {
         super.onDraw(canvas);

         float currentRadius = initialRadius + waveRadiusOffset;
         while (currentRadius < maxRadius) {
             canvas.drawCircle(center.x, center.y, currentRadius, wavePaint);
             currentRadius += 16;
         }
     }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        waveAnimator = new ValueAnimator();
        waveAnimator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator animation) {

                animation.setDuration(1500L);
                animation.setRepeatMode(ValueAnimator.RESTART);
                animation.setRepeatCount(ValueAnimator.INFINITE);
                animation.setInterpolator(new LinearInterpolator());
                animation.start();
            }
        });

//        waveAnimator = ValueAnimator.ofFloat(0f, waveGap).apply {
//            addUpdateListener {
//                waveRadiusOffset = it.animatedValue as Float
//            }
//            duration = 1500L
//            repeatMode = ValueAnimator.RESTART
//            repeatCount = ValueAnimator.INFINITE
//            interpolator = LinearInterpolator()
//            start()
//        }
    }


    @Override
    protected void onDetachedFromWindow() {
         if(waveAnimator!=null){
             waveAnimator.cancel();
         }
         super.onDetachedFromWindow();
    }

     private void init(@Nullable AttributeSet attrs){

         TypedArray a = context.getTheme().obtainStyledAttributes(
                 attrs,
                 R.styleable.SplashView,
                 0, 0);

         wavePaint = new Paint();
         wavePaint.setColor(a.getColor(R.styleable.SplashView_waveColor,0));
         wavePaint.setStrokeWidth(a.getDimension(R.styleable.SplashView_waveStrokeWidth,0f));
         wavePaint.setStyle(Paint.Style.STROKE);

         waveGap = a.getDimension(R.styleable.SplashView_waveGap, 50f);
         a.recycle();
     }
}
